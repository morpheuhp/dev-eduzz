Projeto feito seguindo descritivo: https://gist.github.com/caferrari/a25734c6e941f6386e7156aa723f28a8
Desenvolvido por Fernando Mauricio Camacho
E-mail: morpheu.linux@gmail.com
Telefone: 15 99801-3524

Projeto foi desenvolvido em 15 horas, utilizando-se de única ferramenta externa PHPMailer para envio de e-mails.
Todos os códigos foram desenvolvidos do zero com exceção do PHPMailer que é utilizado para envio dos e-mails., exclusivamente para o propósito único e exclusivo de mostrar 
tempo de programação, organização de código, criatividade, formatação e habilidades com HTML, CSS, Linux e MySql.
